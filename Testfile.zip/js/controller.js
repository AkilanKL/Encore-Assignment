var seekDirection,currentSeekPosotion;
var seekDifference = 0;
var seekObj = {
    initialSeekPosition: 0,
    maxSeekPosition: 0
}

var windowWidth = window.innerWidth;

window.onresize = function() { 
    windowWidth = window.innerWidth; 
    setDragValues();
}

var seekThumbnail = document.querySelector(".seek-thumb");
var seekbar = document.querySelector(".seek-bar-wrapper");
var currentThumbPosition = parseInt(getComputedStyle(seekThumbnail).left);
var seekbarWidth = parseInt(seekbar.clientWidth);
var thumbPrecent = (currentThumbPosition / seekbarWidth);

var tryBtn = document.querySelector(".try-btn");

setDragValues()
function setDragValues() {

        if (windowWidth < 650){
            seekObj.initialSeekPosition = 40;
            seekObj.maxSeekPosition = 270;
        }else if(windowWidth >= 650 && windowWidth < 850){
            seekObj.initialSeekPosition = 70;
            seekObj.maxSeekPosition = 470;
        }else if(windowWidth >= 850 && windowWidth < 1050){
            seekObj.initialSeekPosition = 90;
            seekObj.maxSeekPosition = 570;
        }else if(windowWidth >= 1050){
            seekObj.initialSeekPosition = 140;
            seekObj.maxSeekPosition = 870;
        }


        seekbar = document.querySelector(".seek-bar-wrapper");
        seekbarWidth = parseInt(seekbar.clientWidth);

        seekThumbnail.style.left = Math.floor((thumbPrecent * seekbarWidth)) + "px";
    
}


document.onmousedown =  function(e) {
    e.preventDefault();  
    if(e.target.className == "seek-thumb-img"){
        currentSeekPosotion = e.clientX || e.touches[0].screenX;
        document.onmousemove =  changeSeekPosition;
        document.onmouseup =  clearMouseEvents;
    }
}

document.ontouchstart =  function(e) {
    if(e.target.className == "seek-thumb-img"){
        currentSeekPosotion = e.clientX || e.touches[0].screenX;
        document.ontouchmove =  changeSeekPosition;
        document.ontouchend =  clearMouseEvents;
    }
}


function getseekDirection(e){
    var x = e.clientX || e.touches[0].screenX;
    console.log(x)
    if(x > currentSeekPosotion){
        seekDirection = "right";
        seekDifference = x - currentSeekPosotion;
        currentSeekPosotion = x
    }else if(x < currentSeekPosotion){
        seekDirection = "left";
        seekDifference = x - currentSeekPosotion;
        currentSeekPosotion = x
    }
}

function clearMouseEvents(e){

    document.onmouseup = null;
    document.onmousemove = null;
}


function changeSeekPosition(e){
   console.log(e)
    getseekDirection(e);

    if(currentThumbPosition < seekObj.maxSeekPosition && currentThumbPosition > 0){
    if(seekDirection == "right"){        
        seekThumbnail.style.left = currentThumbPosition + 'px';
    }else if(seekDirection == "left"){
        seekThumbnail.style.left = currentThumbPosition + 'px';
    }

    thumbPrecent = (currentThumbPosition / seekbarWidth);
    }

    currentThumbPosition += seekDifference;

}

function clearSeek() {
    seekThumbnail.style.left = seekObj.initialSeekPosition + "px";
}

tryBtn.onclick = clearSeek;



